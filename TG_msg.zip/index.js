const functions = require('@google-cloud/functions-framework');
const TeleBot2 = require('node-telegram-bot-api');

// 替换成你自己 bot token，在 @BotFather 那里获得。
const token = '6714802559:AAGToYZ0rJlDxWY2NR9ItQt1z111RON8ct4';

// 使用给定的令牌创建 bot 实例.
const bot = new TeleBot2(token, { polling: false });

bot.setWebHook(
    'https://asia-east2-tg-sticker-409404.cloudfunctions.net/tg_msg'
)

bot.on('webhook_error', (error) => {
    console.error('Webhook请求出错', error)
})

// 使用 getMe 方法来获取机器人信息
bot.getMe().then((me) => {
    console.log(`Bot ID: ${me.id}`);
    console.log(`Username: @${me.username}`);
    console.log(`Name: ${me.first_name} ${me.last_name || ''}`);
}).catch((error) => {
    console.error(error);
});
//监听信息通知
bot.on('message', async (msg) => {
    console.log("message----", msg)
    const chatId = msg.chat.id;
    let fileId = ""

    try {
        if (msg.animation && msg.animation.mime_type === "video/mp4") {
            fileId = msg.animation.file_id;
            // 下载接收到的 GIF 消息
            //console.log("Received a gif:", JSON.stringify(msg.animation));
            //提示去下载视频到公众号发送

        } else if (msg.sticker && msg.sticker.file_id) {
            // 下载接收到的 Sticker
            // console.log("Received a sticker:", JSON.stringify(msg.sticker));
            fileId = msg.sticker.file_id;
        }

        console.log("fileId", fileId)

        // 使用 getFile 方法获取附件信息（包括文件路径）
        let fileDetailsResponse = await bot.getFile(fileId);
        console.log("fileDetailsResponse--", fileDetailsResponse)
        if (!fileDetailsResponse.file_size) {
            console.log("无法获取的文件信息!")
            throw new Error(`Failed to get file details for ${fileId}`);
        }

        let url = `https://api.telegram.org/file/bot${token}/${fileDetailsResponse.file_path}`;
        bot.sendMessage(chatId, url);
        bot.sendDocument(chatId, 'cat.gif');
    } catch (error) {
        console.log("error--", error)
    }

});

// 监听文本消息并回复相同内容.
bot.on('text', (msg) => {
    console.log("msg-------", msg)
    const chatId = msg.chat.id;

    // 获取接收到的消息文本内容并发送相同内容作为回复.

    var text = msg.text;
    response = text
    bot.sendMessage(chatId, response);
});



functions.http('helloHttp', (req, res) => {
    console.log("req.body", req.body)
    bot.processUpdate(req.body);
    res.send(`tg_msg ${req.query.name || req.body.name || 'World'}!`);
});
